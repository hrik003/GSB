<?php

//include "config.php";

function Lookup_GoogleSafeBrowsing_v4($url)
{
    $data = '{
      "client": {
        "clientId": "TestClient",
        "clientVersion": "1.0"
      },
      "threatInfo": {
        "threatTypes":      ["MALWARE", "SOCIAL_ENGINEERING"],
        "platformTypes":    ["LINUX"],
        "threatEntryTypes": ["URL"],
        "threatEntries": [
          {"url": "'.$url.'"}
        ]
      }
    }';
 
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, "https://safebrowsing.googleapis.com/v4/threatMatches:find?key=AIzaSyCKCMPzgTBlzusZ1O4A-maTopBmW3p_Ne8");
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array("Content-Type: application/json", 'Content-Length: ' . strlen($data)));
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    $response = (array) json_decode(curl_exec($ch), true);
    curl_close ($ch);
	
	
    return ($response['matches'][0]['threatType']) ? true : false;
	
	
	
}

function check_safe()
{
	$con=connect();
	$query_find=mysqli_query($con, "select * from safe");
	while($row=mysqli_fetch_row($query_find))
	{
		$id=$row[0];
		$url=$row[1];
		$status= Lookup_GoogleSafeBrowsing_v4($url)?"Malware":"Clean";
		//echo $status;
		if($status=="Malware")
		{	
			$query_f=mysqli_query($con, "select * from list where status=0");
			while($rows=mysqli_fetch_row($query_f))
			{
				$id=$rows[0];
				$url1=$rows[1];
			
			
			/*if($url=="http://onlineantivirussecurity.com")
			{
				$url1="google.com";
			}
			elseif($url=="google.com")
			{
				$url1="gumblar.cn";	
			}
			else{}*/
				
				echo $status."<br>";
				echo $url."<br>";
				$query_updt=mysqli_query($con, "UPDATE safe SET url='$url1'");
				if($query_updt)
				{
					echo "hello";
					$file='public_html/zandwagon.com/cron/safev4Fetch.php'; 

					//read file
					$fp=fopen($file, "w");

					// here goes your update
					$content = "<?php \n";
					$content .=	"header('Loaction: ".$url1."');";
					$content .=	"?>";

					//write file
					fwrite($fp, $content);
					fclose($fp);
				}
				$query_upd=mysqli_query($con, "UPDATE list SET status=1 where url='$url1'");
				exit;
			}
		}
	}
}


function connect()
{
	$server = "localhost";
	$username ="cronv4safe";
	$password = "Cron@003";
	$db_name =  "cron_safe";
	$con  = mysqli_connect($server,$username,$password,$db_name);
	return $con;
}
check_safe();
//operation();

  

?>