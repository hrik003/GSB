<?php
function operation()
{
		$con=connect();
		$query_rdt=mysql_query($con, "select * from safe");
		while($row_rdt=mysqli_fetch_row($query_rdt))
		{
			$url_rd=$row_rdt[1];
			echo $url_rd;
			header("Location: http://".$url_rd);
			exit();
		}
	
}
function connect()
{
	$server = "localhost";
	$username ="cronv4safe";
	$password = "Cron@003";
	$db_name =  "cron_safe";
	$con  = mysqli_connect($server,$username,$password,$db_name);
	return $con;
}

?>